WLS Hybrid DR terraform scripts  
Copyright (c) 2022 Oracle and/or its affiliates  
Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/  

## HybridDR_WLSComputeInstances
Terraform code to create the WLS midtier compute instances.

# Usage
In each case, provide your environment values in the terraform.tfvars file. 
Then run "terraform plan" and "terraform apply" to create the resources.
